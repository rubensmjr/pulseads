const CACHE_NAME = 'produtivo-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,500;0,9..40,700;1,9..40,300&family=JetBrains+Mono:wght@400;600&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/react/18.2.0/umd/react.production.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.2.0/umd/react-dom.production.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/babel-standalone/7.23.9/babel.min.js'
];

// ─── Install: cache all assets ───
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(ASSETS))
      .then(() => self.skipWaiting())
  );
});

// ─── Activate: clean old caches ───
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// ─── Fetch: serve from cache, fallback to network ───
self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request))
  );
});

// ─── Background notification check (via periodic sync or message) ───
self.addEventListener('message', e => {
  if (e.data && e.data.type === 'CHECK_BILLS') {
    const bills = e.data.bills || [];
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];
    const tomorrowStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    const hour = now.getHours();

    bills.forEach(b => {
      if (b.paid) return;

      const isToday = b.dueDate === todayStr;
      const isOverdue = b.dueDate < todayStr;
      const isTomorrow = b.dueDate === tomorrowStr;

      if (isOverdue && hour >= 8 && hour <= 22) {
        const daysLate = Math.ceil((new Date(todayStr) - new Date(b.dueDate)) / 86400000);
        self.registration.showNotification(`🚨 Conta atrasada há ${daysLate} dia${daysLate > 1 ? 's' : ''}!`, {
          body: `${b.name} — R$ ${b.amount.toFixed(2)} · Pague agora`,
          tag: `overdue-${b.id}`,
          icon: '/icons/icon-192.png',
          badge: '/icons/icon-192.png',
          vibrate: [200, 100, 200],
          requireInteraction: true,
          data: { billId: b.id }
        });
      } else if (isToday && hour >= 8 && hour <= 22) {
        self.registration.showNotification('💰 Conta vence HOJE!', {
          body: `${b.name} — R$ ${b.amount.toFixed(2)} · Não esqueça de pagar`,
          tag: `today-${b.id}`,
          icon: '/icons/icon-192.png',
          badge: '/icons/icon-192.png',
          vibrate: [200, 100, 200],
          requireInteraction: true,
          data: { billId: b.id }
        });
      } else if (isTomorrow && hour >= 8 && hour <= 10) {
        self.registration.showNotification('📅 Conta vence AMANHÃ', {
          body: `${b.name} — R$ ${b.amount.toFixed(2)}`,
          tag: `tomorrow-${b.id}`,
          icon: '/icons/icon-192.png',
          badge: '/icons/icon-192.png',
          data: { billId: b.id }
        });
      }
    });
  }
});

// ─── Handle notification click: open app ───
self.addEventListener('notificationclick', e => {
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => {
      if (clients.length > 0) {
        return clients[0].focus();
      }
      return self.clients.openWindow('/');
    })
  );
});

// ─── Periodic Background Sync (where supported) ───
self.addEventListener('periodicsync', e => {
  if (e.tag === 'check-bills') {
    e.waitUntil(
      self.clients.matchAll().then(clients => {
        clients.forEach(client => {
          client.postMessage({ type: 'REQUEST_BILLS_CHECK' });
        });
      })
    );
  }
});
